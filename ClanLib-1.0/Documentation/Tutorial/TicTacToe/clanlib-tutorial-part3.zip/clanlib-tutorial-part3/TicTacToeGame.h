#ifndef TICTACTOEGAME_H
#define TICTACTOEGAME_H

// Include necessary CL header files
#include <ClanLib/display.h>
#include <ClanLib/core.h>

class TicTacToeGame {

public:
	TicTacToeGame();
	~TicTacToeGame();

	void loadGraphics();	// Load the game graphics
	void paint();			// Paint the board and moves
	void run();				// Game loop
	void handleMousePress(const CL_InputEvent &key);

private:
	bool alive;
	CL_Surface *board, *o, *x, *menu;
	CL_Slot mousePress;
};

#endif